#ifndef __BKB_TRANSPWND
#define __BKB_TRANSPWND


class BKBTranspWnd
{
public:
	static void Init();
	static void Move(int x, int y);
	static void ToTop(){ SetActiveWindow(Trhwnd); BringWindowToTop(Trhwnd); }
	static void Show(){ ShowWindow(Trhwnd,SW_SHOWNORMAL); }
	static void Hide(){ ShowWindow(Trhwnd,SW_HIDE); }
protected:
	static HWND Trhwnd;
	static int screen_x, screen_y;
};

#endif